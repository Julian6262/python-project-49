### Hexlet tests and linter status:
[![Actions Status](https://github.com/Julian6262/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Julian6262/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/43ff2c2a38821fd8bd90/maintainability)](https://codeclimate.com/github/Julian6262/python-project-49/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/43ff2c2a38821fd8bd90/test_coverage)](https://codeclimate.com/github/Julian6262/python-project-49/test_coverage)
