# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Brain games\nHi! This project includes five mathematical games that will help keep your mind in good shape. Enjoy )\n\n### Requirements\nPython 3.10 or above\n\n### Installation\nUse following commands for installing:\n\n\tpoetry install\n\tpoetry build\n\tpython3 -m pip install dist/*.whl\n\n### Usage\n* Even number: `brain-even`\n* Calculate the expression: `brain-calc`\n* Greatest common divisor: `brain-gcd`\n* Guess missing number: `brain-progression`\n* Prime number: `brain-prime`\n\n\n===========================================================================\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Julian6262/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Julian6262/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/43ff2c2a38821fd8bd90/maintainability)](https://codeclimate.com/github/Julian6262/python-project-49/maintainability)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/43ff2c2a38821fd8bd90/test_coverage)](https://codeclimate.com/github/Julian6262/python-project-49/test_coverage)\n\n\n\n\n### asciinema\n\n#### brain-even [![asciicast](https://asciinema.org/a/547487.svg)](https://asciinema.org/a/547487)\n\n#### brain-calc [![asciicast](https://asciinema.org/a/547564.svg)](https://asciinema.org/a/547564)\n\n#### brain-gcd [![asciicast](https://asciinema.org/a/547565.svg)](https://asciinema.org/a/547565)\n\n#### brain-progression [![asciicast](https://asciinema.org/a/547609.svg)](https://asciinema.org/a/547609)\n',
    'author': 'Dmitry Baburin',
    'author_email': 'd.baburin62@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
